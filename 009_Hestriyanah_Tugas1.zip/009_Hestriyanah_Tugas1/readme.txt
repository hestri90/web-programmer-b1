1. Cara menjalankan aplikasi tugas (index.php)
2. Jika extension menggunakan .php
    > membutuhkan live server (extension)
    > menjalankan dengan perintah php : php -S localhost:2222
3. Jika extension menggunakan .html
    > open file index.html
    > bisa menggunakan live server (extension vscode)
4. isi alasan > mengambil kelas programmer web/ web programming

format pengumpulan
- kodepeserta_namalengkap_tugas1
- 001_riodesra_tugas1.zip

struktur folder
- tugas > menggunakan yang ini
    - index.html/index.php
    - readme.txt
- sesi-1 > menggunakan yang ini